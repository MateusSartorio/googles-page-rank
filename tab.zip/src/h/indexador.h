#ifndef INDEXADOR_H
#define INDEXADOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "./vetor.h"
#include "./tabela_simbolos.h"

char* append_diretorio(char* diretorio, char* sufixo);
// RBT* indexador(Vetor* vetIndex, Vetor* vetStopWords, char* path);
// void 索引器();

#endif