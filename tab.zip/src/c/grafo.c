#include "../h/grafo.h"

static No* init_no(char* chave) {
    No* n = (No*) malloc(sizeof(No));

    n->chave = chave;

    return n;
}

Grafo* init_grafo(int tam) {
    Grafo* g = (Grafo*) malloc(sizeof(Grafo));
    
    g->tam = tam;
    g->vetNos = (No**) malloc(tam*sizeof(No*));

    return g;
}


static void inverte_grafo(Grafo* g) {
    for(int i = 0; i < g->tam; i++) {
        g->vetNos[i]->qtdEntradasMax = TAM_INIC;
        g->vetNos[i]->qtdEntradas = 0;
        g->vetNos[i]->entradas = (No**) malloc(TAM_INIC*sizeof(No*));
    }
}

Grafo* le_grafo(FILE* fg, Vetor* vetIndex, int tam) {
    Grafo* g = init_grafo(tam);

    for(int i = 0; i < tam; i++)
        g->vetNos[i] = init_no(vetIndex->v[i]);
    
    for(int i = 0; i < tam; i++) {
        char* linha = NULL;
        size_t size = 0;
        getline(&linha, &size, fg);

        char* str1 = strtok(linha, " ");
        // g->vetNos[i] = init_no(str1);
        // printf("%s ", str1);

        int n = atoi(strtok(NULL, " "));
        g->vetNos[i]->qtdSaidas = n;
        g->vetNos[i]->saidas = (No**) malloc(n*sizeof(No*));
        // if(n != 0)
        //     printf("%d ", n);
        // else
        //     printf("0\n");

        char* chave = NULL;
        int k = 0;
        for(int j = 0; j < n; j++) {
            chave = strtok(NULL, " \n");
            // if(j < n - 1)
            //     printf("%s ", chave);
            // else
            //     printf("%s\n", chave);

            k = busca_binaria_string(vetIndex->v, chave, 0, tam - 1);
            // printf("k: %d\n", k);
            // printf("O no encontrado eh: %s\n", g->vetNos[k]->chave);

            if(k >= 0)
                g->vetNos[i]->saidas[j] = g->vetNos[k];
        }
    }

    return g;
}

void imprime_grafo(Grafo* g) {
    for(int i = 0; i < g->tam; i++) {
        printf("%s %d ", g->vetNos[i]->chave, g->vetNos[i]->qtdSaidas);
        for(int j = 0; j < g->vetNos[i]->qtdSaidas; j++) {
            if(j < g->vetNos[i]->qtdSaidas - 1)
                printf("%s, ", g->vetNos[i]->saidas[j]->chave);
            else
                printf("%s", g->vetNos[i]->saidas[j]->chave);
        }
        printf("\n");
    }
}

// // void libera_grafo(Grafo** g, int tam) {
// //     for(int i = 0; i < tam; i++) {
// //         free(g[i]->chave);
// //         destroi_lista(g[i]->adjacencias);
// //         free(g[i]);
// //     }
// //     free(g);
// // }