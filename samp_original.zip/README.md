# tecnicas-de-busca-e-ordenacao-trabalho-3
Trabalho 3 de Técnicas de Busca e Ordenação.
Patrocinado pelo Meu Guru.