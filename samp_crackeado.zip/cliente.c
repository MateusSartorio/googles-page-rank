#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "./src/h/vetor.h"
#include "./src/h/grafo.h"
#include "./src/h/indexador.h"
#include "../src/h/lista.h"

void processa_consultas();

int main(int argc, char** argv) {
    char* dir = argv[1];

    char* index = append_diretorio(dir, "index.txt");
    char* stopwords = append_diretorio(dir, "stopwords.txt");
    char* graph = append_diretorio(dir, "graph.txt");
    char* pages = append_diretorio(dir, "pages");

    // printf("%s\n", index);
    // printf("%s\n", stopwords);
    // printf("%s\n", graph);

    FILE* fi = fopen(index, "r");
    FILE* fs = fopen(stopwords, "r");
    FILE* fg = fopen(graph, "r");

    if(!fi || !fs || !fg) {
        printf("Erro na abertura dos arquivos!\n");
        exit(1);
    }

    Vetor* vetorIndex = vetor_strings(fi);
    //imprime_vetor(vetorIndex);

    Vetor* vetorStopwords = vetor_strings(fs);
    // imprime_vetor(vetorStopwords);

    Grafo** g = le_grafo(fg, vetorIndex);
    page_rank(g,vetorIndex->tam);
    // imprime_grafo(g, vetorIndex->tam);

    RBT* tab_sim = indexador(vetorIndex, vetorStopwords, pages);
    // RBT_imprime(tab_sim);

    processa_consultas(tab_sim, vetorStopwords);

    RBT_libera(tab_sim);
    libera_grafo(g, vetorIndex->tam);
    destroi_vetor(vetorIndex);
    destroi_vetor(vetorStopwords);

    fclose(fi);
    fclose(fs);
    fclose(fg);
        
    free(index);
    free(stopwords);
    free(graph);
    free(pages);

    return 0;
}

void processa_consultas(RBT* tab_sim, Vetor* vetorStopwords) {
    while(1) {
        if(feof(stdin))
            break;
        char* linha;
        size_t size = 0;

        getline(&linha, &size, stdin);
        to_lower(linha);
        // printf("%s\n", linha);

        Lista** vetListas = (Lista**) malloc(TAM_INIC*sizeof(Lista*));
        int tamMaxVetListas = TAM_INIC;
        int tamVetListas = 0;

        Grafo** vetDocumentos = (Grafo**) malloc(TAM_INIC*sizeof(Grafo*));
        int tamMaxVetDocs = TAM_INIC;
        int tamVetDocs = 0;

        char* termo = strtok(linha, " \n");
        while(termo) {
            // printf("%s\n", termo);
            int k = busca_binaria_string(vetorStopwords->v, termo, 0, vetorStopwords->tam - 1);
            // printf("%d\n", k);
            // if(k >= 0)
            //     printf("%s\n", termo);
            
            Lista* l = busca(tab_sim, termo);
            if(l) {
                vetListas[tamVetListas++] = l;
                if(tamVetListas >= tamMaxVetListas) {
                    vetListas = (Lista**) realloc(vetListas, 2*tamMaxVetListas*sizeof(Lista*));
                    tamMaxVetListas *= 2;
                }
                // printf("\"%s\" -> {", termo);
                // imprime_lista(l);
                // printf("}\n");
            }

            termo = strtok(NULL, " \n");
        }
        
        Celula* temp = vetListas[0]->prim;
        while(temp) {
            char* termo = temp->chave;

            for(int j = 1; j < tamMaxVetListas; j++) {
                Celula* temp2 = vetListas[j]->prim;
                while(temp2) {
                    


                    temp2 = temp2->prox;
                }                
            }

            temp = temp->prox;
        }
        
        free(linha);

        free(vetListas);
    }
}